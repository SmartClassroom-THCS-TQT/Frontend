<template>
  <h1>Kết quả thi đua</h1>
</template>

<script>
export default {

}
</script>

<style>

</style>